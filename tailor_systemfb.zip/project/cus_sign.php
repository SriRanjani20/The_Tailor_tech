<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'tailorconnect.php';

    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Debugging: Print SQL query
        echo "SQL: SELECT * FROM `cus_login` WHERE `username` = '$username'";

        // Check if the username already exists
        $sql = "SELECT * FROM `cus_login` WHERE `username` = '$username'";
        $result = mysqli_query($con, $sql);

        if ($result) {
            $num_rows = mysqli_num_rows($result);
            if ($num_rows > 0) {
                echo "User already exists!";
            } else {
                // Insert the new user into the database
                $sql = "INSERT INTO `cus_login` (`username`, `password`) VALUES ('$username', '$hashed_password')";
                echo "SQL: $sql"; // Debugging: Print SQL query
                $result = mysqli_query($con, $sql);
                if ($result) {
                    echo "Signup successful";
                } else {
                    die(mysqli_error($con));
                }
            }
        } 
        //else {
          //  die(mysqli_error($con));
        //}
    } else {
        echo "Username or password not set.";
    }
} 
//else {
   // echo "Invalid request method.";
//}
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Login</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }

    .container {
      max-width: 400px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #333;
    }

    .form-group label {
      color: #333;
    }

    button {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 4px;
      background-color: #3498db;
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #2980b9;
    }

    .signup-link {
      text-align: center;
      margin-top: 15px;
      color: #3498db;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>Customer Login</h1>

    <form id="loginForm" action="gender.html" method="post">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
      </div>

      <button type="submit" class="btn btn-primary">Login</button>
    </form>

    <p class="signup-link">Don't have an account? <a href="signup.html">Sign up here</a></p>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script>
    function validateForm() {
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;

      if (username === "" || password === "") {
        alert("Both username and password are required.");
        return false;
      }

      if (password.length < 6) {
        alert("Password must be at least 6 characters long.");
        return false;
      }

      return true; // Allow form submission
    }

    function login() {
      // Dummy login function to simulate login process
      alert('Login function called');
    }
  </script>
</body>
</html>
