
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'tailorconnect.php';
    
    if (isset($_POST['signup-username']) && isset($_POST['signup-password'])) {
        $username = $_POST['signup-username'];
        $password = $_POST['signup-password'];
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Check if the username already exists
        $sql = "SELECT * FROM `tailor_login` WHERE `username` = '$username'";
        $result = mysqli_query($con, $sql);

        if ($result) {
            $num_rows = mysqli_num_rows($result);
            if ($num_rows > 0) {
                echo "User already exists!";
            } else {
                // Insert the new user into the database
                $sql = "INSERT INTO `tailor_login` (`username`, `password`) VALUES ('$username', '$hashed_password')";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    echo "Signup successful";
                } else {
                    die(mysqli_error($con));
                }
            }
        } else {
            die(mysqli_error($con));
        }
    } else {
        echo "Username or password not set.";
    }
} 
//else {
  //  echo "Invalid request method.";
//}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAILOR LOGIN</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        .success-message {
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>TAILOR LOGIN</h1>
        </header>
        <form action="tailor_profile.html" method="post">
            <section id="signup">
                <h2>Signup</h2>
                <div class="form-group">
                    <label for="signup-username">Username:</label>
                    <input type="text" class="form-control" id="signup-username" name="signup-username" required>
                </div>
                <div class="form-group">
                    <label for="signup-password">Password:</label>
                    <input type="password" class="form-control" id="signup-password" name="signup-password" required>
                </div>
                <button type="submit" class="btn btn-primary">Signup</button>
            </section>
        </form>
    </div>
</body>
</html>
