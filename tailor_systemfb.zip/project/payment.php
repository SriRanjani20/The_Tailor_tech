<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'tailorconnect.php'; // Ensure this path is correct

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve and sanitize form inputs
    $card_number = mysqli_real_escape_string($con, $_POST['card_number']);
    $expiry_date = mysqli_real_escape_string($con, $_POST['expiry_date']);
    $cvv = mysqli_real_escape_string($con, $_POST['cvv']);
    $card_type = mysqli_real_escape_string($con, $_POST['card_type']);
    $upi_id = mysqli_real_escape_string($con, $_POST['upi_id']);
    $bank = mysqli_real_escape_string($con, $_POST['bank']);

    // SQL query to insert data into the table
    $sql = "INSERT INTO payment (card_number, expiry_date, cvv, card_type, upi_id, bank) VALUES (?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($con, $sql)) {
        mysqli_stmt_bind_param($stmt, "isisss", $card_number, $expiry_date, $cvv, $card_type, $upi_id, $bank);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Payment processed successfully!');</script>";
            //echo "<script>setTimeout(function(){ window.location.href = 'payment_success.html'; }, 2000);</script>";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
      }// else {
    //    echo "Error preparing statement: " . mysqli_error($con);
   // }

    mysqli_close($con);
} else {
    echo "No data submitted.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }

    .container {
      max-width: 600px;
      margin: 50px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }

    .input-section {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      color: #333;
    }

    input[type="text"],
    input[type="number"],
    input[type="date"],
    select {
      width: 100%;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }

    button {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 4px;
      background-color: #3498db;
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #2980b9;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>KUTTU.COM - Payment</h1>
    <form action="paysucc.html" method="post">
      <div class="input-section">
        <label for="cardNumber">Card Number:</label>
        <input type="text" name="card_number" id="cardNumber" placeholder="Enter card number" >
      </div>

      <div class="input-section">
        <label for="expiryDate">Expiry Date:</label>
        <input type="date" name="expiry_date" id="expiryDate" >
      </div>

      <div class="input-section">
        <label for="cvv">CVV:</label>
        <input type="number" name="cvv" id="cvv" placeholder="Enter CVV" >
      </div>

      <div class="input-section">
        <label for="cardType">Card Type:</label>
        <select name="card_type" id="cardType" >
          <option value="">Select Card Type</option>
          <option value="visa">Visa</option>
          <option value="mastercard">MasterCard</option>
          <option value="amex">American Express</option>
        </select>
      </div>

      <div class="input-section">
        <label for="upiId">UPI ID:</label>
        <input type="text" name="upi_id" id="upiId" placeholder="Enter UPI ID" >
      </div>

      <div class="input-section">
        <label for="bank">Select Bank:</label>
        <select name="bank" id="bank" required>
          <option value="">Select Bank</option>
          <option value="hdfc">HDFC Bank</option>
          <option value="icici">ICICI Bank</option>
          <option value="axis">Axis Bank</option>
          <option value="sbi">State Bank of India</option>
        </select>
      </div>

      <button type="submit">Proceed to Pay</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
