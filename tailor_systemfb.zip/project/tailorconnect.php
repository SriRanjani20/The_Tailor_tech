<?php
$HOSTNAME='localhost';
$USERNAME='root';
$PASSWORD='';
$database='tailoring_system';

$con=mysqli_connect($HOSTNAME,$USERNAME,$PASSWORD,$database);
 if($con){
    echo "conneted successfully";
}else{
    die(mysqli_error($con));
}

?>