<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'tailorconnect.php'; // Ensure this path is correct

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve and sanitize form input
    $due_date = mysqli_real_escape_string($con, $_POST['due_date']);

    // SQL query to insert data into the table
    $sql = "INSERT INTO due_date (due_date) VALUES (?)";

    if ($stmt = mysqli_prepare($con, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $due_date);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Due date submitted successfully!');</script>";
          //  echo "<script>setTimeout(function(){ window.location.href = 'Payment.html'; }, 2000);</script>";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($con);
    }

    mysqli_close($con);
} 
//else {
  //  echo "No data submitted.";
//}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Your Due Date</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .alert {
            display: none;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Select the Date</h1>
        <form action="payment.php" method="post" id="dueDateForm" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="dueDate">Select Due Date:</label>
                <input type="date" name="due_date" id="dueDate" class="form-control" required>
                <div class="invalid-feedback">
                    Please select a due date.
                </div>
            </div>
            <button type="submit" class="btn">Submit Due Date</button>
        </form>
        <div class="alert alert-success mt-3" id="successMessage">
            Due date submitted successfully!
        </div>
    </div>
    
    <script>
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
