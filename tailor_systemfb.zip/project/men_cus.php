<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'tailorconnect.php'; // Ensure this path is correct

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $dressType = mysqli_real_escape_string($con, $_POST['dresstype']);
    $design = mysqli_real_escape_string($con, $_POST['design']);
    $hip = (int)$_POST['hip_measurement'];
    $shoulder = (int)$_POST['shoulder_measurement'];
    $handLength = (int)$_POST['hand_length_meas'];
    $chest = (int)$_POST['chest_measurement'];
    $bottoom_Wear = mysqli_real_escape_string($con, $_POST['bottoom_wear']);

    $sql = "INSERT INTO men_cus (dresstype, design, hip_measurement, shoulder_measurement, hand_length_meas, chest_measurement, bottoom_wear) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    if ($stmt = mysqli_prepare($con, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssiiiii", $dressType, $design, $hip, $shoulder, $handLength, $chest, $bottoom_Wear);

        if (mysqli_stmt_execute($stmt)) {
            echo "Record added successfully.";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($con);
    }

    mysqli_close($con);
} 
//else {
  //  echo "No data submitted.";
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tailor and Customer</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    .container {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #333;
    }

    .input-section {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      color: #333;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    button {
      display: block;
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 4px;
      background-color: #3498db;
      color: #fff;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #2980b9;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Male's Dress Customization</h1>
    <form method="post" action="due_date.php">
      <div class="input-section">
        <label for="dressType">Choose the type of dress:</label>
        <select id="dressType" name="dresstype" required>
          <option value="" disabled selected>Select dress type</option>
          <option value="Shirt">Shirt</option>
          <option value="Suit">Suit</option>
          <option value="Kurta">Kurta</option>
        </select>
      </div>

      <div class="input-section">
        <label for="designChoice">Choose your design:</label>
        <select id="designChoice" name="design" required>
          <option value="" disabled selected>Select dress design</option>
          <option value="Double vent">Double vent</option>
          <option value="Nehru jacket">Nehru jacket</option>
          <option value="Double breasted suit">Double breasted suit</option>
        </select>
      </div>

      <div class="input-section">
        <label for="hip">Hip Measurement:</label>
        <input type="number" id="hip" name="hip_measurement" placeholder="Enter hip measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="shoulders">Shoulders Measurement:</label>
        <input type="number" id="shoulders" name="shoulder_measurement" placeholder="Enter shoulders measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="handLength">Hand Length Measurement:</label>
        <input type="number" id="handLength" name="hand_length_meas" placeholder="Enter hand length measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="chest">Chest Measurement:</label>
        <input type="number" id="chest" name="chest_measurement" placeholder="Enter chest measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="bottomwear">Choose your bottomwear:</label>
        <select id="bottomwear" name="bottoom_wear" required>
          <option value="" disabled selected>Select bottomwear</option>
          <option value="Formal Pant">Formal Pant</option>
          <option value="Dothi">Dothi</option>
        </select>
      </div>

      <button type="submit">Submit</button>
    </form>
  </div>
</body>
</html>
