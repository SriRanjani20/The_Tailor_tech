<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'tailorconnect.php'; // Ensure this path is correct

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve and sanitize form inputs
    $dressType = mysqli_real_escape_string($con, $_POST['dressTypeId']);
    //$designChoice = mysqli_real_escape_string($con, $_POST['designChoice']);
    $sleeves = mysqli_real_escape_string($con, $_POST['sleeves']);
    $collars = mysqli_real_escape_string($con, $_POST['collars']);
    $bottomWear = mysqli_real_escape_string($con, $_POST['bottomWear']);
    $hip = (int)$_POST['hip'];
    $shoulders = (int)$_POST['shoulders'];
    $handLength = (int)$_POST['handLength'];
    $chest = (int)$_POST['chest'];

    // SQL query to insert data into the table
    $sql = "INSERT INTO women_cus (dresstype, sleeves, collar, bottom_wear, hip_measurement, shoulders_measurement, hand_length_meas, chest_measurement) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = mysqli_prepare($con, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssssiiii", $dressType, $sleeves, $collars, $bottomWear, $hip, $shoulders, $handLength, $chest);

        if (mysqli_stmt_execute($stmt)) {
            echo "Record added successfully.";
        } else {
            echo "Error: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($con);
    }

    mysqli_close($con);
} else {
    echo "No data submitted.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tailor and Customer</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 800px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .light-purple-bg {
      background-color: #E6E6FA;
    }

    h1 {
      text-align: center;
      color: #ea14b4;
    }

    .input-section {
      margin-bottom: 24px;
      background-color: hsl(300, 87%, 37%);
      padding: 15px;
      border-radius: 8px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      color: white;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }

    button {
      display: block;
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 4px;
      background-color: #fff;
      color: #333;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #eee;
    }
  </style>
</head>
<body>

  <div class="container light-purple-bg">
    <h1>Female's Dress Customization</h1>

    <form action="payment.php" method="post">
      <div class="input-section">
        <label for="dressTypeId">Choose the type of dress:</label>
        <select id="dressTypeId" name="dressTypeId" class="form-control" required>
          <option value="">Select dress type</option>
          <option value="Lehanga">Lehanga/Half sareee</option>
          <option value="cocktail">Cocktail Dress</option>
          <option value="Kurthi">Kurthi</option>
          <option value="Gown">Gown</option>
          <option value="Anarkali">Anarkali Dress</option>
          <option value="Blouse">Blouse</option>
        </select>
      </div>

        

      <div class="input-section">
        <label for="sleeves">Select type of sleeves:</label>
        <select id="sleeves" name="sleeves" class="form-control" required>
          <option value="Regular">Regular</option>
          <option value="short">Short Sleeves</option>
          <option value="long">Long Sleeves</option>
          <option value="sleeveless">Sleeveless</option>
          <option value="Bishop">Bishop Sleeves</option>
          <option value="Puff">Puff Sleeves</option>
          <option value="Drop">Drop Sleeves</option>
        </select>
      </div>

      <div class="input-section">
        <label for="collars">Select type of collar:</label>
        <select id="collars" name="collars" class="form-control" required>
          <option value="Regular">Regular</option>
          <option value="round">Round Collar</option>
          <option value="v-neck">V-Neck</option>
          <option value="shirt">Shirt Collar</option>
          <option value="club">Club collar</option>
          <option value="bell">Bell collar</option>
          <option value="Cuban">Cuban collar</option>
        </select>
      </div>

      <div class="input-section">
        <label for="bottomWear">Select type of bottom wear:</label>
        <select id="bottomWear" name="bottomWear" class="form-control" >
          <option value="">Select bottom wear</option>
          <option value="pants">Pants</option>
          <option value="skirt">Skirt</option>
          <option value="shorts">Shorts</option>
        </select>
      </div>

      <div class="input-section">
        <label for="hip">Hip Measurement:</label>
        <input type="number" id="hip" name="hip" class="form-control" placeholder="Enter hip measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="shoulders">Shoulders Measurement:</label>
        <input type="number" id="shoulders" name="shoulders" class="form-control" placeholder="Enter shoulders measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="handLength">Hand Length Measurement:</label>
        <input type="number" id="handLength" name="handLength" class="form-control" placeholder="Enter hand length measurement in inches" required>
      </div>

      <div class="input-section">
        <label for="chest">Chest Measurement:</label>
        <input type="number" id="chest" name="chest" class="form-control" placeholder="Enter chest measurement in inches" required>
      </div>

      <button type="submit">Submit</button>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
